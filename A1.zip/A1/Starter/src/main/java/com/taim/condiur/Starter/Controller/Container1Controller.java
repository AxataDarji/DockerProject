package com.taim.condiur.Starter.Controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

@RestController
@RequestMapping("/")
@Validated
public class Container1Controller
{
    @Autowired
    private Gson gson;

    @Autowired
    private RestTemplate restTemplate;

    @RequestMapping(value = "/calculate", method = RequestMethod.POST)
    public ResponseEntity<?> handlePostRequest(@RequestBody String fileJsonInput)
    {
        JsonObject jsonObjectInput=gson.fromJson(fileJsonInput, JsonObject.class);
        if (jsonObjectInput.has("file") && jsonObjectInput.get("file").isJsonNull()) {
            return ResponseEntity.ok("{\"file\": null, \"error\": \"Invalid JSON input.\"}");
        }
        String fileNameInput = jsonObjectInput.get("file").getAsString();
        if (!Files.exists(Paths.get("/shared/" + fileNameInput))) {
            return ResponseEntity.ok("{\"file\": \"" + fileNameInput + "\", \"error\": \"File not found.\"}");
        }
        try (BufferedReader reader = new BufferedReader(new FileReader("/shared/" + fileNameInput))) {
            boolean isValidCSV = isCSVFormat(reader);
            if (!isValidCSV) {
                return ResponseEntity.ok("{\"file\": \"" + fileNameInput + "\", \"error\": \"Input file not in CSV format.\"}");
            }
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> request = new HttpEntity<>(fileJsonInput, headers);
            ResponseEntity<String> response = restTemplate.postForEntity("http://dockera1-container2:9001/get-product-sum", request, String.class);
            //ResponseEntity<String> response = restTemplate.postForEntity("http://loclhost:9001/get-product-sum", request, String.class);
            String responseJsonData = response.getBody();

            return ResponseEntity.ok(responseJsonData);

        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.ok("{\"file\": \"" + fileNameInput + "\", \"error\": \"Error reading file.\"}");
        }
//        InputStream inputStream = Container1Controller.class.getClassLoader().getResourceAsStream("./shared/" + fileNameInput);
//        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
//            boolean isValidCSV = isCSVFormat(reader);
//            if (!isValidCSV) {
//                return ResponseEntity.ok("{\"file\": \"" + fileNameInput + "\", \"error\": \"Input file not in CSV format.\"}");
//            }
//            HttpHeaders headers = new HttpHeaders();
//            headers.setContentType(MediaType.APPLICATION_JSON);
//            HttpEntity<String> request = new HttpEntity<>(fileJsonInput, headers);
//            //ResponseEntity<String> response = restTemplate.postForEntity("http://dockera1-container2:9001/get-product-sum", request, String.class);
//            ResponseEntity<String> response = restTemplate.postForEntity("http://localhost:9002/get-product-sum", request, String.class);
//            String responseJsonData = response.getBody();
//
//            return ResponseEntity.ok(responseJsonData);
//
//        } catch (IOException e) {
//            e.printStackTrace();
//            return ResponseEntity.ok("{\"file\": \"" + fileNameInput + "\", \"error\": \"Error reading file.\"}");
//        }
    }
    private boolean isCSVFormat(BufferedReader reader) throws IOException {
        String line;

        while ((line = reader.readLine()) != null) {
            String[] columns = line.split(",");

            // Check if the line doesn't contain exactly two columns
            if (columns.length != 2) {
                return false;
            }
        }
        return true;
    }
}
