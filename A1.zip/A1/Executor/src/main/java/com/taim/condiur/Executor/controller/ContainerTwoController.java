package com.taim.condiur.Executor.controller;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.*;

@RestController
@RequestMapping("/")
@Validated
public class ContainerTwoController
{
    @Autowired
    private Gson gson;

    @RequestMapping(value = "/get-product-sum", method = RequestMethod.POST)
    public ResponseEntity<?> handleIncommingPostRequest(@RequestBody String recievedFileJsonInput) {

        System.out.println("Input String: " + recievedFileJsonInput);
        JsonObject jsonObjectInput = gson.fromJson(recievedFileJsonInput, JsonObject.class);
        String fileName = jsonObjectInput.get("file").getAsString();
        String productName = jsonObjectInput.get("product").getAsString();

        int sum = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader("/shared/" + fileName))) {
            sum = calculateSum(productName, reader);
            System.out.println("Sum: " + sum);

        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.ok("{\"file\": \"" + fileName + "\", \"error\": \"Error reading file.\"}");
        }
        return ResponseEntity.ok("{\"file\": \"" + fileName + "\", \"sum\": " + sum + "}");
    }

    public Integer calculateSum(String productName, BufferedReader reader) throws IOException {
        int sum = 0;
        String line;
        boolean headerSkipped = false; // Flag to skip the header line
        while ((line = reader.readLine()) != null) {
            if (!headerSkipped) {
                headerSkipped = true;
                continue; // Skip the header line
            }
            System.out.println("line: " + line);
            String[] values = line.split(",");
            if (values.length != 2) {
                // Handle invalid line format
                System.err.println("Invalid format for line: " + line);
                continue;
            }
            try {
                if(productName.equalsIgnoreCase(values[0].trim())){
                    int value = Integer.parseInt(values[1].trim());
                    sum += value;
                }
            } catch (NumberFormatException e) {
                // Handle invalid integer format
                System.err.println("Invalid integer format for line: " + line);
            }
        }
        return sum;
    }
}
