package com.taim.condiur.Executor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExecutorApplicationTests {

	@Test
	void contextLoads() {
	}

}
